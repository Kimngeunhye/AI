import os
import numpy as np
import librosa
import soundfile as sf
import tensorflow as tf
from keras import layers, models
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import pyaudio
import wave
import pickle
import noisereduce as nr


# MFCC 추출 함수
def extract_mfcc(file_path, n_mfcc=13):
    y, sr = sf.read(file_path)
    y, _ = librosa.effects.trim(y)
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
    mfcc_mean = np.mean(mfcc.T, axis=0)
    return mfcc_mean


# 음성 녹음 함수 및 노이즈 제거
def record_audio(filename, duration=5):
    os.makedirs(os.path.dirname(filename), exist_ok=True)

    p = pyaudio.PyAudio()
    format = pyaudio.paInt16
    channels = 1
    rate = 16000
    frames_per_buffer = 1024

    stream = p.open(format=format, channels=channels, rate=rate, input=True, frames_per_buffer=frames_per_buffer)
    print("Recording...")
    frames = [stream.read(frames_per_buffer) for _ in range(0, int(rate / frames_per_buffer * duration))]
    print("Recording finished.")

    stream.stop_stream()
    stream.close()
    p.terminate()

    with wave.open(filename, 'wb') as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(p.get_sample_size(format))
        wf.setframerate(rate)
        wf.writeframes(b''.join(frames))

    y, sr = librosa.load(filename, sr=16000)
    reduced_noise = nr.reduce_noise(y=y, sr=sr)
    sf.write(filename, reduced_noise, sr)
    print(f"Noise reduction applied to {filename}.")


# RNN 모델 생성 함수
def create_model(input_shape, num_classes):
    model = models.Sequential()
    model.add(layers.Input(shape=input_shape))
    model.add(layers.SimpleRNN(64, activation='relu'))
    model.add(layers.Dense(64, activation='relu'))
    model.add(layers.Dense(num_classes, activation='softmax'))
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model


# 사용자 등록 함수
def register_user(username):
    folder = f"C:\\AI\\multiclass_dataset\\{username}"
    os.makedirs(folder, exist_ok=True)
    for i in range(3):
        file_path = os.path.join(folder, f"{username}_{i + 1}.wav")
        print(f"{i + 1}번째 음성을 녹음합니다...")
        record_audio(file_path, duration=5)
    print(f"{username}님의 음성이 저장되었습니다.")

    # 회원가입 후 자동으로 모델 재학습
    train_model()


# 로그인 함수
def login():
    temp_path = "C:\\AI\\temp\\login.wav"
    record_audio(temp_path, duration=5)

    # 모델 불러오기
    model = tf.keras.models.load_model("C:\\AI\\models\\multiclass_voice_model.h5")
    classes = np.load("C:\\AI\\models\\label_classes.npy")

    # 특성 추출 및 예측
    features = extract_mfcc(temp_path).reshape(1, -1, 1)
    prediction = model.predict(features)
    predicted_label = classes[np.argmax(prediction)]

    print(f"로그인한 사용자: {predicted_label}")


# 전체 데이터 불러오기 및 모델 훈련
def train_model():
    dataset_path = "C:\\AI\\multiclass_dataset"
    X, y = [], []
    for user_folder in os.listdir(dataset_path):
        user_path = os.path.join(dataset_path, user_folder)
        if os.path.isdir(user_path):
            for file in os.listdir(user_path):
                if file.endswith('.wav'):
                    file_path = os.path.join(user_path, file)
                    features = extract_mfcc(file_path)
                    X.append(features)
                    y.append(user_folder)

    X = np.array(X)
    y = np.array(y)
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)
    X = X.reshape((X.shape[0], X.shape[1], 1))

    X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

    model = create_model(input_shape=(X.shape[1], 1), num_classes=len(le.classes_))
    history = model.fit(X_train, y_train, epochs=20, validation_data=(X_test, y_test))

    model.save("C:\\AI\\models\\multiclass_voice_model.h5")
    np.save("C:\\AI\\models\\label_classes.npy", le.classes_)

    print("\n모델 학습 완료")
    print(f"최종 학습 정확도: {history.history['accuracy'][-1]:.4f}")
    print(f"최종 검증 정확도: {history.history['val_accuracy'][-1]:.4f}")


# 메인 실행
if __name__ == "__main__":
    while True:
        print("\n메뉴를 선택하세요:")
        print("1. 로그인")
        print("2. 회원가입")
        print("0. 종료")
        choice = input("선택 (1/2/0): ")

        if choice == '1':
            login()
        elif choice == '2':
            username = input("회원가입할 사용자 이름을 입력하세요: ")
            register_user(username)  # 회원가입 후 자동으로 모델 재학습
        elif choice == '0':
            print("프로그램을 종료합니다.")
            break
        else:
            print("잘못된 선택입니다. 다시 시도해주세요.")
