import tensorflow as tf

print("TensorFlow version:", tf.__version__)
print("Keras version:", tf.keras.__version__)

# TensorFlow version: 2.19.0
# Keras version: 3.9.0


